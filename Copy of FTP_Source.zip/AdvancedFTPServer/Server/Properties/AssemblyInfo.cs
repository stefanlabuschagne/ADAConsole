﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
[assembly: AssemblyTitle("Advanced FTP Server")]
[assembly: AssemblyDescription("Enables remote access to your files and folders")]
[assembly: AssemblyCompany("ExpertDotNet")]
[assembly: AssemblyProduct("Advanced FTP Server")]
[assembly: AssemblyCopyright("Copyright © ExpertDotNet 2009")]
[assembly: ComVisible(false)]
[assembly: Guid("e8ffa0ce-8c5f-4e66-b3cf-01044bb069f2")]
[assembly: AssemblyVersion("1.2.0.0")]
[assembly: AssemblyFileVersion("1.2.0.0")]