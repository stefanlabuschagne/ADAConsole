﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
[assembly: AssemblyTitle("Advanced FTP Server")]
[assembly: AssemblyDescription("Enables remote access to your files and folders.")]
[assembly: AssemblyCompany("ExpertDotNet")]
[assembly: AssemblyProduct("FTPServer")]
[assembly: AssemblyCopyright("Copyright © ExpertDotNet 2009")]
[assembly: ComVisible(false)]
[assembly: Guid("0768e75d-2884-425e-a653-f77377bb374c")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]